<form action="" method="post">
  <div>
    <input type="hidden" name="action" value="logout">
    <input type="hidden" name="goto" value="/admin/">
    <input type="submit" value="Log out">
  </div>
</form>
