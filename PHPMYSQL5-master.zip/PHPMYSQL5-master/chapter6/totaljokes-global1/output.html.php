<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Calculate Area</title>
  </head>
  <body>
    <p>
      Total jokes: <?php echo $totalJokes; ?>
    </p>
  </body>
</html>
