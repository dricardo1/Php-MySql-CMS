<p id="footer">
	The contents of this web page are copyright &copy;
	1998&ndash;<?php echo date('Y'); ?> Example Pty. Ltd.
	All Rights Reserved.
</p>
