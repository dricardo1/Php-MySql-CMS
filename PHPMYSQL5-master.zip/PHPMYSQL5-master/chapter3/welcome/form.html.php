<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Form Example</title>
  </head>
  <body>
    <form action="" method="post">
      <div><label for="firstname">First name:
        <input type="text" name="firstname" id="firstname"></label>
      </div>
      <div><label for="lastname">Last name:
        <input type="text" name="lastname" id="lastname"></label>
      </div>
      <div><input type="submit" value="GO"></div>
    </form>
  </body>
</html>
