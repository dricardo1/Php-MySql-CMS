<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Counting to Ten</title>
  </head>
  <body>
    <p>
      <?php
      for ($count = 1; $count <= 10; ++$count)
      {
        echo "$count ";
      }
      ?>
    </p>
  </body>
</html>
