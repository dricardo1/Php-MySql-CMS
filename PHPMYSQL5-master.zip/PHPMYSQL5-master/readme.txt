Note regarding database connection parameters
---------------------------------------------

Most of the database connection function calls in the
.php files included here use the 'root' username and a fictitious
'mypassword' password. To use these scripts, you will have to change the
username and password for all the files to your actual database username
and password.

The scripts also use 'ijdb' as the database name in the PDO('mysql:host=localhost;dbname=ijdb' … )
calls. Be sure to set the name to match that on your server.