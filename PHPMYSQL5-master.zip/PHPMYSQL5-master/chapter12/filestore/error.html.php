<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset=utf-8"/>
		<title>PHP Error</title>
	</head>
	<body>
		<p>
			<?php echo $error; ?>
		</p>
	</body>
</html>
